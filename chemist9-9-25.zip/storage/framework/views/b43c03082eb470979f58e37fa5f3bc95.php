<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('assets/admin/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/node-waves/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/pages/plugins/lord-icon-2.1.0.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/plugins.js')); ?>"></script>

<!-- apexcharts -->
<script src="<?php echo e(asset('assets/admin/libs/apexcharts/apexcharts.min.js')); ?>"></script>

<!-- Vector map-->
<script src="<?php echo e(asset('assets/admin/libs/jsvectormap/jsvectormap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/jsvectormap/maps/world-merc.js')); ?>"></script>

<!-- Swiper slider js-->
<script src="<?php echo e(asset('assets/admin/libs/swiper/swiper-bundle.min.js')); ?>"></script>

<!-- Dashboard init -->
<script src="<?php echo e(asset('assets/admin/js/pages/dashboard-ecommerce.init.js')); ?>"></script>

<!-- App js -->
<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>




<!-- prismjs plugin -->
<script src="<?php echo e(asset('assets/admin/libs/prismjs/prism.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/list.js/list.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/libs/list.pagination.js/list.pagination.min.js')); ?>"></script>

<!-- listjs init -->
<script src="<?php echo e(asset('assets/admin/js/pages/listjs.init.js')); ?>"></script>

<!-- Sweet Alerts js -->
<script src="<?php echo e(asset('assets/admin/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>



<?php /**PATH G:\xampp\htdocs\Chemist\resources\views/admin/layout/footer-links.blade.php ENDPATH**/ ?>