    <link rel="shortcut icon" href="<?php echo e(asset('assets/logo/' . $gs->favicon)); ?>">

    <!-- jsvectormap css -->
    <link href="<?php echo e(asset('assets/admin/libs/jsvectormap/jsvectormap.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--Swiper slider css-->
    <link href="<?php echo e(asset('assets/admin/libs/swiper/swiper-bundle.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="<?php echo e(asset('assets/admin/js/layout.js')); ?>"></script>
    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('assets/admin/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('assets/admin/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="<?php echo e(asset('assets/admin/css/custom.min.css')); ?>" rel="stylesheet" type="text/css" /><?php /**PATH G:\xampp\htdocs\Chemist\resources\views/admin/layout/header-links.blade.php ENDPATH**/ ?>