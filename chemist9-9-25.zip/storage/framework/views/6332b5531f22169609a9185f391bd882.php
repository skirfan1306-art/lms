<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable" data-theme="default" data-theme-colors="default">
<head>

    <meta charset="utf-8" />
    <title><?php echo e($gs->title ?? 'Chemist'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <?php echo $__env->make('admin.layout.header-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
<?php
    $authPages = ['admin.login','admin.register','admin.forgot','admin.forgot.otp','admin.password.reset'];
?>
    <!-- Begin page -->
    <div id="layout-wrapper">
<?php if(!request()->routeIs($authPages)): ?>
<?php echo $__env->make('admin.layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endif; ?>



<?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
<div class="alert alert-success alert-border-left alert-dismissible fade show material-shadow" role="alert"
style="position: fixed; left: 50%; z-index: 9999999999; width: max-content; top: 10px; transform: translateX(-50%);" >
    <i class="ri-check-double-line align-middle"></i> <strong>Success</strong> - <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
<?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
<div class="alert alert-danger alert-border-left alert-dismissible fade show material-shadow" role="alert"
style="position: fixed; left: 50%; z-index: 9999999999; width: max-content; top: 10px; transform: translateX(-50%);">
    <i class="ri-error-warning-line me-3 align-middle"></i> <strong>Danger</strong> - <?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-border-left alert-dismissible fade show material-shadow" 
         style="position: fixed; left: 50%; z-index: 9999999999; width: max-content; top: 10px; transform: translateX(-50%);" 
         role="alert">
        <i class="ri-error-warning-line me-3 align-middle"></i> 
        <strong>Danger</strong> - Please fix the following errors:
        <ul class="mb-0 mt-2">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>



        <!-- ========== App Menu ========== -->
        <?php if(!request()->routeIs($authPages)): ?>
        <?php echo $__env->make('admin.layout.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
        <!-- Left Sidebar End -->
        <!-- Vertical Overlay-->
        <div class="vertical-overlay"></div>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->

        <?php echo $__env->yieldContent('main.content'); ?>
        
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->



    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top" style="bottom: 40px">
        <i class="ri-arrow-up-line"></i>
    </button>
    <!--end back-to-top-->

    <!--preloader-->
    <div id="preloader">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.layout.footer-links', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH /home/rwhhbxot/chemist.synergynexa.com/resources/views/admin/layout/app.blade.php ENDPATH**/ ?>