<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Subscriber;

class SubscriberController extends Controller
{
    public function insert(Request $req)
    {
        $req->validate([
            'email' => 'required|email|unique:subscribers,email',
        ]);

        $subscriber = new Subscriber();
        $subscriber->name = $req->firstname ." ". $req->lastname;
        $subscriber->email = $req->email;
        $subscriber->created_at = now()->setTimezone('Asia/Kolkata');

        if ($subscriber->save()) {
            return redirect()->back()->with('success', 'You have successfully subscribed!');
        } else {
            return redirect()->back()->with('error', 'Something went wrong. Please try again later.');
        }
    }
    
    
    public function delete($id)
    {

        $subscriber = Subscriber::find($id);

        if ($subscriber->delete()) {
            return redirect()->back()->with('success', 'Subscriber Deleted.');
        } else {
            return redirect()->back()->with('error', 'Something went wrong. Please try again later.');
        }
    }
}
