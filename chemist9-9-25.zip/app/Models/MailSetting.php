<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MailSetting extends Model
{
    protected $table = "mail_settings";
    protected $guarded = [];
    public $timestamps = false;
}
