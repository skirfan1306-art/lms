@extends('admin.layout.app')

@php
$products = [
    [
        'id' => 1,
        'name' => 'Paracetamol 500mg',
        'slug' => 'paracetamol-500mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 50,
        'image' => 'https://images.openai.com/thumbnails/url/PLZQJHicu1mSUVJSUGylr5-al1xUWVCSmqJbkpRnoJdeXJJYkpmsl5yfq5-Zm5ieWmxfaAuUsXL0S7F0Tw4280vJCEr1zw00ywxI1fXzcy5JqooKdHWxSE120jXxNvHwqfI2MQkx9nByK07xqsiNSko1jSrytnBxTVcrBgD3Diix',
        'status' => '1',
    ],
    [
        'id' => 2,
        'name' => 'Amoxicillin Capsules',
        'slug' => 'amoxicillin-capsules',
        'category' => ['id' => 2, 'name' => 'Antibiotic'],
        'price' => 120,
        'image' => 'https://via.placeholder.com/80?text=Amoxicillin',
        'status' => '1',
    ],
    [
        'id' => 3,
        'name' => 'Ibuprofen 200mg',
        'slug' => 'ibuprofen-200mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 70,
        'image' => 'https://via.placeholder.com/80?text=Ibuprofen',
        'status' => '1',
    ],
    [
        'id' => 4,
        'name' => 'Cetirizine Tablets',
        'slug' => 'cetirizine-tablets',
        'category' => ['id' => 3, 'name' => 'Antihistamine'],
        'price' => 90,
        'image' => 'https://via.placeholder.com/80?text=Cetirizine',
        'status' => '0',
    ],
    [
        'id' => 5,
        'name' => 'Metformin 500mg',
        'slug' => 'metformin-500mg',
        'category' => ['id' => 4, 'name' => 'Antidiabetic'],
        'price' => 60,
        'image' => 'https://via.placeholder.com/80?text=Metformin',
        'status' => '1',
    ],
    [
        'id' => 6,
        'name' => 'Omeprazole 20mg',
        'slug' => 'omeprazole-20mg',
        'category' => ['id' => 5, 'name' => 'Gastrointestinal'],
        'price' => 85,
        'image' => 'https://via.placeholder.com/80?text=Omeprazole',
        'status' => '1',
    ],
    [
        'id' => 7,
        'name' => 'Vitamin C Tablets',
        'slug' => 'vitamin-c-tablets',
        'category' => ['id' => 6, 'name' => 'Supplements'],
        'price' => 40,
        'image' => 'https://via.placeholder.com/80?text=Vitamin+C',
        'status' => '1',
    ],
    [
        'id' => 8,
        'name' => 'Cough Syrup',
        'slug' => 'cough-syrup',
        'category' => ['id' => 7, 'name' => 'Cold & Flu'],
        'price' => 110,
        'image' => 'https://via.placeholder.com/80?text=Cough+Syrup',
        'status' => '0',
    ],
    [
        'id' => 9,
        'name' => 'Aspirin 100mg',
        'slug' => 'aspirin-100mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 55,
        'image' => 'https://via.placeholder.com/80?text=Aspirin',
        'status' => '1',
    ],
    [
        'id' => 10,
        'name' => 'Metronidazole 400mg',
        'slug' => 'metronidazole-400mg',
        'category' => ['id' => 2, 'name' => 'Antibiotic'],
        'price' => 130,
        'image' => 'https://via.placeholder.com/80?text=Metronidazole',
        'status' => '0',
    ],
    [
        'id' => 11,
        'name' => 'Loratadine 10mg',
        'slug' => 'loratadine-10mg',
        'category' => ['id' => 3, 'name' => 'Antihistamine'],
        'price' => 95,
        'image' => 'https://via.placeholder.com/80?text=Loratadine',
        'status' => '1',
    ],
    [
        'id' => 12,
        'name' => 'Prednisolone 5mg',
        'slug' => 'prednisolone-5mg',
        'category' => ['id' => 8, 'name' => 'Steroid'],
        'price' => 150,
        'image' => 'https://via.placeholder.com/80?text=Prednisolone',
        'status' => '1',
    ],
        [
        'id' => 1,
        'name' => 'Paracetamol 500mg',
        'slug' => 'paracetamol-500mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 50,
        'image' => 'https://images.openai.com/thumbnails/url/PLZQJHicu1mSUVJSUGylr5-al1xUWVCSmqJbkpRnoJdeXJJYkpmsl5yfq5-Zm5ieWmxfaAuUsXL0S7F0Tw4280vJCEr1zw00ywxI1fXzcy5JqooKdHWxSE120jXxNvHwqfI2MQkx9nByK07xqsiNSko1jSrytnBxTVcrBgD3Diix',
        'status' => '1',
    ],
    [
        'id' => 2,
        'name' => 'Amoxicillin Capsules',
        'slug' => 'amoxicillin-capsules',
        'category' => ['id' => 2, 'name' => 'Antibiotic'],
        'price' => 120,
        'image' => 'https://via.placeholder.com/80?text=Amoxicillin',
        'status' => '1',
    ],
    [
        'id' => 3,
        'name' => 'Ibuprofen 200mg',
        'slug' => 'ibuprofen-200mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 70,
        'image' => 'https://via.placeholder.com/80?text=Ibuprofen',
        'status' => '1',
    ],
    [
        'id' => 4,
        'name' => 'Cetirizine Tablets',
        'slug' => 'cetirizine-tablets',
        'category' => ['id' => 3, 'name' => 'Antihistamine'],
        'price' => 90,
        'image' => 'https://via.placeholder.com/80?text=Cetirizine',
        'status' => '0',
    ],
    [
        'id' => 5,
        'name' => 'Metformin 500mg',
        'slug' => 'metformin-500mg',
        'category' => ['id' => 4, 'name' => 'Antidiabetic'],
        'price' => 60,
        'image' => 'https://via.placeholder.com/80?text=Metformin',
        'status' => '1',
    ],
    [
        'id' => 6,
        'name' => 'Omeprazole 20mg',
        'slug' => 'omeprazole-20mg',
        'category' => ['id' => 5, 'name' => 'Gastrointestinal'],
        'price' => 85,
        'image' => 'https://via.placeholder.com/80?text=Omeprazole',
        'status' => '1',
    ],
    [
        'id' => 7,
        'name' => 'Vitamin C Tablets',
        'slug' => 'vitamin-c-tablets',
        'category' => ['id' => 6, 'name' => 'Supplements'],
        'price' => 40,
        'image' => 'https://via.placeholder.com/80?text=Vitamin+C',
        'status' => '1',
    ],
    [
        'id' => 8,
        'name' => 'Cough Syrup',
        'slug' => 'cough-syrup',
        'category' => ['id' => 7, 'name' => 'Cold & Flu'],
        'price' => 110,
        'image' => 'https://via.placeholder.com/80?text=Cough+Syrup',
        'status' => '0',
    ],
    [
        'id' => 9,
        'name' => 'Aspirin 100mg',
        'slug' => 'aspirin-100mg',
        'category' => ['id' => 1, 'name' => 'Analgesic'],
        'price' => 55,
        'image' => 'https://via.placeholder.com/80?text=Aspirin',
        'status' => '1',
    ],
    [
        'id' => 10,
        'name' => 'Metronidazole 400mg',
        'slug' => 'metronidazole-400mg',
        'category' => ['id' => 2, 'name' => 'Antibiotic'],
        'price' => 130,
        'image' => 'https://via.placeholder.com/80?text=Metronidazole',
        'status' => '0',
    ],
    [
        'id' => 11,
        'name' => 'Loratadine 10mg',
        'slug' => 'loratadine-10mg',
        'category' => ['id' => 3, 'name' => 'Antihistamine'],
        'price' => 95,
        'image' => 'https://via.placeholder.com/80?text=Loratadine',
        'status' => '1',
    ],
    [
        'id' => 12,
        'name' => 'Prednisolone 5mg',
        'slug' => 'prednisolone-5mg',
        'category' => ['id' => 8, 'name' => 'Steroid'],
        'price' => 150,
        'image' => 'https://via.placeholder.com/80?text=Prednisolone',
        'status' => '1',
    ],
];
@endphp

@section('main.content')
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mb-0">Products</h4>
                        </div><!-- end card header -->

                        <div class="card-body">
                            <div class="listjs-table" id="customerList">
                                <div class="row g-4 mb-3">
                                    <div class="col-sm-auto">
                                        <div>
                                            <a href="{{ route('admin.product.form') }}" class="btn btn-success"><i class="ri-add-line align-bottom me-1"></i> Create New Product</a>
                                        </div>
                                    </div>
                                    <div class="col-sm">
                                        <div class="d-flex justify-content-sm-end">
                                            <div class="search-box ms-2">
                                                <input type="text" class="form-control search" placeholder="Search...">
                                                <i class="ri-search-line search-icon"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive table-card mt-3 mb-1">
                                    


<table class="table align-middle table-nowrap" id="medicineTable">
    <thead class="table-light">
        <tr>
            <th>#</th>
            <th>Image</th>
            <th data-sort="name">Name</th>
            <th data-sort="one">Category</th>
            <th data-sort="two">Price</th>
            <th data-sort="status">Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody class="list form-check-all">
        @foreach($products as $p)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>
                <img src="{{ $p['image'] }}" alt="{{ $p['name'] }}" class="rounded avatar-sm">
            </td>
            <td class="name">{{ $p['name'] }}</td>
            <td class="one">{{ $p['category']['name'] }}</td>
            <td class="two">₹{{ number_format($p['price'], 2) }}</td>
            <td>
                @if($p['status'] == '1')
                    <span class="badge bg-success-subtle text-success status">Active</span>
                @else
                    <span class="badge bg-danger-subtle text-danger status">Inactive</span>
                @endif
            </td>
            <td>
                <div class="d-flex gap-2">
                    <form action="" method="POST">
                        @csrf
                        <input type="hidden" name="id" value="{{ $p['id'] }}">
                        @if($p['status'] == '1')
                            <button class="btn btn-sm btn-danger">Inactive</button>
                        @else
                            <button class="btn btn-sm btn-success">Active</button>
                        @endif
                    </form>
                    <button class="btn btn-sm btn-success edit-item-btn"
                            data-bs-toggle="modal"
                            data-id="{{ $p['id'] }}"
                            data-name="{{ $p['name'] }}"
                            data-price="{{ $p['price'] }}"
                            data-image="{{ $p['image'] }}"
                            data-bs-target="#editMedicineModal">
                        <i class="bx bx-pen"></i>
                    </button>
                    <button class="btn btn-sm btn-danger remove-item-btn"
                            data-id="{{ $p['id'] }}"
                            data-bs-toggle="modal"
                            data-bs-target="#deleteRecordModal">
                        <i class="bx bx-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>



                                    <div class="noresult" style="display: none">
                                        <div class="text-center">
                                            <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop" colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px"></lord-icon>
                                            <h5 class="mt-2">Sorry! No Result Found</h5>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-end">
                                    <div class="pagination-wrap hstack gap-2">

                                        <ul class="pagination listjs-pagination mb-0"></ul>

                                    </div>
                                </div>
                            </div>
                        </div><!-- end card -->
                    </div>
                    <!-- end col -->
                </div>
                <!-- end col -->
            </div>


            <!-- Modal -->
            <div class="modal fade zoomIn" id="deleteRecordModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="btn-close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mt-2 text-center">
                                <lord-icon src="https://cdn.lordicon.com/gsqxdxog.json" trigger="loop" colors="primary:#f7b84b,secondary:#f06548" style="width:100px;height:100px"></lord-icon>
                                <div class="mt-4 pt-2 fs-15 mx-4 mx-sm-5">
                                    <h4>Are you Sure ?</h4>
                                    <p class="text-muted mx-4 mb-0">Are you Sure You want to Delete this Product ?</p>
                                </div>
                            </div>
                            <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                                <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                                <form action="{{ route('admin.category.delete') }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="id" id="deleteId" value="">
                                    <button class="btn w-sm btn-danger " id="delete-record">Yes, Delete It!</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end modal -->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    @include('admin.layout.footer')
</div>
@endsection
@section('scripts')
<script>

document.addEventListener("click", function (e) {
    if (e.target.classList.contains("remove-item-btn")) {
        let deleteId = e.target.getAttribute("data-id");
        document.getElementById("deleteId").value = deleteId;
    }
});
</script>

@endsection