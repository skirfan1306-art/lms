@extends('admin.layout.app')

@section('main.content')
<div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header align-items-center d-flex">
                                    <h4 class="card-title mb-0 flex-grow-1">Form Example</h4>
                                    
                                </div><!-- end card header -->
                                <form action="" method="POST" enctype="multipart/form-data">
                                <div class="card-body">
                                    <div class="live-preview">
                                        <div class="row gy-4">
                                            
                                             <div class="col-md-6">
                                                <div>
                                                    <label for="placeholderInput" class="form-label">Title</label>
                                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Placeholder" name='title'>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div>
                                                    <label for="placeholderInput" class="form-label">Link</label>
                                                    <input type="text" class="form-control" id="placeholderInput" placeholder="Placeholder" name='link'>
                                                </div>
                                            </div>
                                         
                        
                                           
                                            <div class="col-md-6">
                                                <div>
                                                    <label for="exampleFormControlTextarea5" class="form-label">Description</label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea5" rows="3" name='description'></textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="col-md-6">
                                                <div>
                                                    <label for="exampleFormControlTextarea5" class="form-label">SVG</label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea5" rows="3" name='svg'></textarea>
                                                </div>
                                            </div>
                                             
                                             
                                            
                                             <div>
                                                    
                                                    <div class="form-check mb-2">
                                                        <input class="form-check-input" type="radio" name="class" id="flexRadioDefault1" value='left-top'>
                                                        <label class="form-check-label" for="flexRadioDefault1">
                                                            Left Top Corner
                                                        </label>
                                                    </div>
                                                    <div class="form-check mb-4">
                                                        <input class="form-check-input" type="radio" name="class" id="flexRadioDefault2" checked="" value='right-bottom'>
                                                        <label class="form-check-label" for="flexRadioDefault2">
                                                            Right Bottom Corner
                                                        </label>
                                                    </div>
                                                </div>
                                           
                                        </div>
                                        <!--end row-->
                                   

                                        <a href="" class="btn btn-danger btn-label waves-effect waves-light">
                                            <i class="ri-delete-bin-5-line label-icon align-middle fs-16 me-2"></i> Cancel</a>

                                        <button type="submit" class="btn btn-success btn-label waves-effect waves-light">
                                            <i class="ri-check-double-line label-icon align-middle fs-16 me-2"></i> Success</button>
                                    </div>
                                    
                                </div>
                                </form>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->



                </div> <!-- container-fluid -->
            </div><!-- End Page-content -->

            @include('admin.layout.footer')
        </div>
@endsection