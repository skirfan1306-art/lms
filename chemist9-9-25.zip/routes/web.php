<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Front\SubscriberController;

Route::get('/', function () {
    return view('front.index');
});
Route::get('products', function () {
    return view('front.products');
});


Route::post('add-subscribers', [SubscriberController::class, 'insert'])->name('front.addSuscriber');


